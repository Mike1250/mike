#!/bin/sh
set -eu
python_bin=""
for p in python3 python; do
    if command -v "$p" >/dev/null 2>&1; then python_bin="$p"; break; fi
done
if [ -z "$python_bin" ]; then
    echo "ERROR: python3/python is required for safe lamedb cleanup" >&2
    exit 1
fi
"$python_bin" - <<'PY'
from __future__ import print_function
import os, re, shutil, time
# Exact hidden PIDs used by the V13.15.7 Abertis profile table.
pids = {
    2025,2026,2027,2028,2050,2060,
    2270,2271,2272,2273,2274,
    2200,2201,2202,2203,2204,2205,
    2100,2101,2102,2103,2104,2105,
    2300,2301,2302,2303,2304,2305,
    2400,2401,2402,2403,2404,2405,
    2500,2501,2502,2503,2504,2505,
}
# Also match only the exact v2 shape: c:15hhhh plus C:2600 on the same record.
# We remove the c:15 token only if hhhh is one of the known hidden PIDs; C:2600
# is removed only on a record where such a token was removed in this pass.
for path in ("/etc/enigma2/lamedb", "/etc/enigma2/lamedb5"):
    if not os.path.exists(path):
        continue
    with open(path, "r") as f:
        lines = f.read().splitlines()
    changed = 0
    out = []
    for line in lines:
        toks = line.split(',')
        bad = False
        kept = []
        for tok in toks:
            m = re.fullmatch(r"c:15([0-9A-Fa-f]{4})", tok.strip())
            if m and int(m.group(1), 16) in pids:
                bad = True
                changed += 1
                continue
            kept.append(tok)
        if bad:
            kept2 = []
            removed_caid = False
            for tok in kept:
                if not removed_caid and tok.strip().upper() == "C:2600":
                    removed_caid = True
                    continue
                kept2.append(tok)
            line = ','.join(kept2)
        out.append(line)
    if changed:
        stamp = time.strftime("%Y%m%d-%H%M%S")
        bak = path + ".before-v2-cleanup-" + stamp
        shutil.copy2(path, bak)
        tmp = path + ".abertis-safe-v3.tmp"
        with open(tmp, "w") as f:
            f.write("\n".join(out) + "\n")
        os.rename(tmp, path)
        print("cleaned: %s (%d bad c:15 entries removed)" % (path, changed))
        print("backup:  %s" % bak)
    else:
        print("no v2 Abertis c:15 metadata found in %s" % path)
PY
echo "Cleanup complete. Install recovery-safe v3 and restart Enigma2."
