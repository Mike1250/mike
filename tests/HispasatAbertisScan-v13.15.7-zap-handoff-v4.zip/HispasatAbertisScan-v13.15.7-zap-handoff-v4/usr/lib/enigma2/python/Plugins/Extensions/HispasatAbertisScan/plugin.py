# -*- coding: utf-8 -*-
# Hispasat Abertis hidden-carrier scan helper V13.15.7 + automatic OSCam zap handoff v4
# GPL-2.0-or-later

from __future__ import print_function

import os
import re
import time
import shutil

from enigma import (
    eComponentScan,
    eDVBFrontendParametersSatellite,
    eServiceReference,
    eTimer,
    eDVBDB,
)
from Screens.Screen import Screen
from Screens.ChoiceBox import ChoiceBox
from Screens.MessageBox import MessageBox
from Components.Label import Label
from Components.ProgressBar import ProgressBar
from Components.ActionMap import ActionMap
from Components.NimManager import nimmanager
from Plugins.Plugin import PluginDescriptor

PARAM_BASE = "/sys/module/aml_hardware_dmx/parameters"
PARAM_PID = PARAM_BASE + "/e2_abertis_force_pid"
PARAM_SID = PARAM_BASE + "/e2_abertis_force_sid"
PARAM_ENABLE = PARAM_BASE + "/e2_abertis_hispasat"
PARAM_HITS = PARAM_BASE + "/e2_abertis_hits"
PARAM_LAST_PID = PARAM_BASE + "/e2_abertis_last_pid"
PARAM_FORCE_READY = PARAM_BASE + "/e2_abertis_force_ready_hits"
PARAM_INNER = PARAM_BASE + "/e2_abertis_inner_packets"
PARAM_HOLD_ENABLE = PARAM_BASE + "/e2_abertis_helper_cw_hold"
PARAM_HOLD_PID = PARAM_BASE + "/e2_abertis_helper_hold_pid"
PARAM_HOLD_REUSES = PARAM_BASE + "/e2_abertis_helper_cw_reuses"
LOGFILE = "/tmp/hispasat_abertis_scan.log"
ORBITAL_POSITION = 3300  # 30.0W in Enigma2's 0..3599 representation

# name, RF frequency kHz, symbol-rate, polarisation, [(source SID, hidden PID), ...]
PROFILES = [
    ("11222H", 11222000, 30000000, "H", [(3025,2025),(3026,2026),(3027,2027),(3028,2028),(3050,2050),(3060,2060)]),
    ("11302H", 11302000, 30000000, "H", [(3270,2270),(3271,2271),(3272,2272),(3273,2273),(3274,2274)]),
    ("11347H", 11347000, 20858000, "H", [(3302,2302),(3303,2303),(3305,2305),(3306,2306),(3308,2308)]),
    ("11382H", 11382000, 30000000, "H", [(3520,2520),(3521,2521),(3522,2522),(3523,2523),(3524,2524)]),
    ("11502V", 11502000, 10200000, "V", [(1801,801)]),
    ("11653H", 11653000, 19680000, "H", [(1301,301),(1303,303)]),
    ("11675H", 11675000, 15750000, "H", [(1420,420),(1421,421),(1423,423)]),
    ("12548V", 12548000, 29600000, "V", [(1701,701),(1702,702),(1703,703)]),
    ("12583V", 12583000, 16900000, "V", [(1008,8008)]),
    ("12631V", 12631000, 30000000, "V", [(1001,8001),(1002,8002),(1003,8003)]),
    ("12671V", 12671000, 30000000, "V", [(1000,8000),(1004,8004),(1005,8005),(1006,8006)]),
]


def log(msg):
    line = time.strftime("%H:%M:%S") + " " + str(msg)
    print("[HispasatAbertisScan] " + line)
    try:
        with open(LOGFILE, "a") as f:
            f.write(line + "\n")
    except Exception:
        pass


def read_int(path, default=-1):
    try:
        with open(path, "r") as f:
            return int(f.read().strip(), 0)
    except Exception:
        return default


def write_param(path, value):
    with open(path, "w") as f:
        f.write(str(value))


def timer_connect(timer, fn):
    try:
        timer.callback.append(fn)
    except Exception:
        timer.timeout.connect(fn)


def find_dvbs_tuner():
    for slot in nimmanager.nim_slots:
        try:
            if slot.isCompatible("DVB-S") or slot.isCompatible("DVB-S2") or slot.isCompatible("DVB-S2X"):
                return int(slot.slot)
        except Exception:
            try:
                if slot.isCompatible("DVB-S"):
                    return int(slot.slot)
            except Exception:
                pass
    return -1


def build_satparm(profile):
    name, freq, sr, pol, carriers = profile
    p = eDVBFrontendParametersSatellite()
    p.frequency = int(freq)
    p.symbol_rate = int(sr)
    p.polarisation = (eDVBFrontendParametersSatellite.Polarisation_Horizontal
                      if pol == "H" else eDVBFrontendParametersSatellite.Polarisation_Vertical)
    p.fec = getattr(eDVBFrontendParametersSatellite, "FEC_Auto", 0)
    p.inversion = getattr(eDVBFrontendParametersSatellite, "Inversion_Unknown", 2)
    p.orbital_position = ORBITAL_POSITION
    p.system = getattr(eDVBFrontendParametersSatellite, "System_DVB_S2", 1)
    p.modulation = getattr(eDVBFrontendParametersSatellite, "Modulation_8PSK", 2)
    p.rolloff = getattr(eDVBFrontendParametersSatellite, "RollOff_alpha_0_35", 0)
    p.pilot = getattr(eDVBFrontendParametersSatellite, "Pilot_Unknown", 2)
    # Never request MIS/T2-MI through Enigma2 for Abertis hidden carriers.
    if hasattr(p, "is_id"):
        p.is_id = getattr(eDVBFrontendParametersSatellite, "No_Stream_Id_Filter", -1)
    if hasattr(p, "pls_mode"):
        p.pls_mode = getattr(eDVBFrontendParametersSatellite, "PLS_Gold", 1)
    if hasattr(p, "pls_code"):
        p.pls_code = getattr(eDVBFrontendParametersSatellite, "PLS_Default_Gold_Code", 0)
    if hasattr(p, "t2mi_plp_id"):
        p.t2mi_plp_id = getattr(eDVBFrontendParametersSatellite, "No_T2MI_PLP_Id", -1)
    if hasattr(p, "t2mi_pid"):
        p.t2mi_pid = getattr(eDVBFrontendParametersSatellite, "T2MI_Default_Pid", 4096)
    return p


def _parse_hex(s):
    try:
        return int(s, 16)
    except Exception:
        return None


def _sat_namespace_matches(ns):
    try:
        return ((int(ns) >> 16) & 0xffff) == ORBITAL_POSITION
    except Exception:
        return False


def _make_data_ref(source_sid, ns, tsid, onid):
    # The hidden Abertis source services are data services.  Type 0xC is the
    # same Enigma2 service-reference type used by the working Abertis/Astra
    # source-service method; the transponder tuple comes from lamedb itself.
    return "1:0:C:%X:%X:%X:%X:0:0:0:" % (
        int(source_sid), int(tsid), int(onid), int(ns))


def find_source_ref(source_sid, frequency):
    """Return an outer Abertis source reference for one hidden carrier.

    Prefer a real service already stored in lamedb.  If Enigma2 deliberately
    omits the data service from its service list, synthesize only the service
    reference while reusing the exact namespace/TSID/ONID of the physical RF
    transponder already present in lamedb.  No transponder identity is guessed.
    """
    path = "/etc/enigma2/lamedb"
    if not os.path.exists(path):
        return None
    try:
        with open(path, "r") as f:
            lines = [x.rstrip("\n") for x in f]
    except Exception:
        return None

    transponders = {}

    # lamedb4
    in_tp = False
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        if line == "transponders":
            in_tp = True
            i += 1
            continue
        if in_tp and line == "end":
            in_tp = False
        if in_tp and re.match(r"^[0-9a-fA-F]+:[0-9a-fA-F]+:[0-9a-fA-F]+$", line):
            parts = line.split(":")
            if len(parts) == 3:
                ns = _parse_hex(parts[0]); tsid = _parse_hex(parts[1]); onid = _parse_hex(parts[2])
                if None not in (ns, tsid, onid) and i + 1 < len(lines):
                    par = lines[i + 1].strip()
                    m = re.search(r"\bs\s+([0-9]+):([0-9]+):", par)
                    if m:
                        transponders[(ns, tsid, onid)] = int(m.group(1))
            i += 1
        i += 1

    in_services = False
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        if line == "services":
            in_services = True
            i += 1
            continue
        if in_services and line == "end":
            break
        if in_services:
            parts = line.split(":")
            if len(parts) >= 6:
                vals = [_parse_hex(x) for x in parts[:6]]
                if None not in vals:
                    sid, ns, tsid, onid, stype, flags = vals
                    f = transponders.get((ns, tsid, onid))
                    if sid == int(source_sid) and f is not None and abs(f - int(frequency)) <= 3000:
                        return "1:0:%X:%X:%X:%X:%X:0:0:0:" % (stype, sid, tsid, onid, ns)
        i += 1

    # lamedb5 transponders/services.  Merge with any v4 tuples so images that
    # keep compatibility sections are handled as well.
    for line in lines:
        if not line.startswith("t:"):
            continue
        left = line.split(",", 1)[0]
        lp = left.split(":")
        if len(lp) < 4:
            continue
        ns = _parse_hex(lp[1]); tsid = _parse_hex(lp[2]); onid = _parse_hex(lp[3])
        if None in (ns, tsid, onid):
            continue
        m = re.search(r"(?:^|,)s:([0-9]+):([0-9]+):", line)
        if m:
            transponders[(ns, tsid, onid)] = int(m.group(1))

    for line in lines:
        if not line.startswith("s:"):
            continue
        left = line.split(",", 1)[0]
        q = left.split(":")
        if len(q) < 7:
            continue
        vals = [_parse_hex(x) for x in q[1:7]]
        if None in vals:
            continue
        sid, ns, tsid, onid, stype, flags = vals
        f = transponders.get((ns, tsid, onid))
        if sid == int(source_sid) and f is not None and abs(f - int(frequency)) <= 3000:
            return "1:0:%X:%X:%X:%X:%X:0:0:0:" % (stype, sid, tsid, onid, ns)

    # The data SID can be intentionally absent from lamedb.  Reuse the exact
    # physical transponder identity and construct only the data-service ref.
    candidates = []
    for (ns, tsid, onid), f in transponders.items():
        if abs(f - int(frequency)) <= 3000:
            candidates.append((0 if _sat_namespace_matches(ns) else 1, ns, tsid, onid, f))
    if candidates:
        candidates.sort()
        _, ns, tsid, onid, f = candidates[0]
        ref = _make_data_ref(source_sid, ns, tsid, onid)
        log("source SID %d absent from lamedb; synthetic data ref from physical TP ns=%X tsid=%X onid=%X freq=%d" %
            (source_sid, ns, tsid, onid, f))
        return ref
    return None


def _service_ref_parts(refstr):
    """Parse a normal DVB service reference into numeric identity fields."""
    try:
        parts = str(refstr).split(":")
        if len(parts) < 7 or parts[0] != "1":
            return None
        return {
            "stype": int(parts[2], 16),
            "sid": int(parts[3], 16),
            "tsid": int(parts[4], 16),
            "onid": int(parts[5], 16),
            "ns": int(parts[6], 16),
        }
    except Exception:
        return None


def _safe_service_name(name):
    try:
        name = str(name or "").replace("\\n", " ").replace("\\r", " ")
    except Exception:
        name = ""
    return name.strip() or "Abertis service"


def _lamedb_path():
    # This image family normally uses /etc/enigma2/lamedb.  Accept lamedb5
    # too so the helper does not silently fail on an image configured for v5.
    for path in ("/etc/enigma2/lamedb", "/etc/enigma2/lamedb5"):
        if os.path.exists(path):
            return path
    return "/etc/enigma2/lamedb"


def _find_rf_params_v4(lines, frequency, symbol_rate):
    for line in lines:
        q = line.strip()
        if not q.startswith("s "):
            continue
        vals = q[2:].split(":")
        try:
            if abs(int(vals[0]) - int(frequency)) <= 3000 and abs(int(vals[1]) - int(symbol_rate)) <= 3000:
                return q
        except Exception:
            pass
    return None


def _find_rf_params_v5(lines, frequency, symbol_rate):
    for line in lines:
        if not line.startswith("t:") or ",s:" not in line:
            continue
        tail = line.split(",", 1)[1].strip()
        vals = tail[2:].split(":") if tail.startswith("s:") else []
        try:
            if abs(int(vals[0]) - int(frequency)) <= 3000 and abs(int(vals[1]) - int(symbol_rate)) <= 3000:
                return tail
        except Exception:
            pass
    return None


def _ref_string(ref):
    try:
        return ref.toString()
    except Exception:
        try:
            return str(ref)
        except Exception:
            return ""


class AbertisScanRunner(Screen):
    skin = """
    <screen name="AbertisScanRunner" position="center,center" size="980,340" title="Hispasat Abertis Scan">
        <widget name="status" position="35,35" size="910,120" font="Regular;27" />
        <widget name="detail" position="35,165" size="910,70" font="Regular;22" />
        <widget name="progress" position="35,250" size="910,28" />
        <widget name="hint" position="35,295" size="910,30" font="Regular;19" />
    </screen>
    """

    def __init__(self, session, mode):
        Screen.__init__(self, session)
        self["status"] = Label("Preparing Hispasat Abertis scan...")
        self["detail"] = Label("")
        self["progress"] = ProgressBar()
        self["hint"] = Label("EXIT: cancel and restore normal automatic Abertis mode")
        self["actions"] = ActionMap(["OkCancelActions"], {"cancel": self.cancel}, -1)

        self.mode = mode
        self.queue = self._make_queue(mode)
        self.index = 0
        self.scan = None
        self.scan_pid = -1
        self.scan_hits_before = 0
        self.scan_retry = 0
        self.scan_had_source = False
        self.bootstrap_scan = False
        self.source_hits_before = 0
        self.source_ready_before = 0
        self.source_wait_deadline = 0
        self.post_verify_deadline = 0
        self.post_verify_info = None
        self.cancelled = False
        self.timer = eTimer()
        timer_connect(self.timer, self._timer_fired)
        self.pending_action = None
        self.saved_service = session.nav.getCurrentlyPlayingServiceOrGroup()
        self.saved_pid = read_int(PARAM_PID, -1)
        self.saved_sid = read_int(PARAM_SID, -1)
        self.saved_enable = read_int(PARAM_ENABLE, 1)
        self.saved_hold_enable = read_int(PARAM_HOLD_ENABLE, 0)
        self.saved_hold_pid = read_int(PARAM_HOLD_PID, -1)
        self.feid = find_dvbs_tuner()
        self.results = []
        self.scan_found_services = []
        self.all_found_services = []
        self.committed_services = []
        self.lamedb_backup = None
        self.retry_queue = []
        self.retry_pass = False
        # Candidate #1 may already be the live persistent Abertis bridge when
        # the helper opens.  Clean it once before the first source activation
        # so candidate #1 takes the same stop -> reacquire -> probe path as
        # every later candidate.
        self.first_source_transition_done = False
        self.onShown.append(self._start_once)
        self._started = False

    def _make_queue(self, mode):
        q = []
        if mode == "test":
            p = PROFILES[0]
            for sid, pid in p[4][:2]:
                q.append((p, sid, pid))
            return q
        if mode.startswith("profile:"):
            name = mode.split(":", 1)[1]
            for p in PROFILES:
                if p[0] == name:
                    for sid, pid in p[4]:
                        q.append((p, sid, pid))
                    return q
            return q
        for p in PROFILES:
            for sid, pid in p[4]:
                q.append((p, sid, pid))
        return q

    def _start_once(self):
        if self._started:
            return
        self._started = True
        try:
            open(LOGFILE, "w").close()
        except Exception:
            pass
        if self.feid < 0:
            self.session.open(MessageBox, "No DVB-S/S2 tuner is configured.", MessageBox.TYPE_ERROR)
            self.close()
            return
        if (not os.path.exists(PARAM_PID) or not os.path.exists(PARAM_SID) or
                not os.path.exists(PARAM_HOLD_ENABLE) or not os.path.exists(PARAM_HOLD_PID)):
            self.session.open(MessageBox,
                "V13.15.6+ helper handoff is not available.\nInstall the matching aml_hardware_dmx first.",
                MessageBox.TYPE_ERROR)
            self.close()
            return
        self._next()

    def _set_timer(self, ms, action):
        self.pending_action = action
        try:
            self.timer.start(int(ms), True)
        except TypeError:
            self.timer.start(int(ms), 1)

    def _timer_fired(self):
        a = self.pending_action
        self.pending_action = None
        if a and not self.cancelled:
            a()

    def _next(self):
        if self.cancelled:
            return
        if self.index >= len(self.queue):
            if self.retry_queue and not self.retry_pass:
                log("starting second pass for %d carrier(s) that did not activate on first attempt" % len(self.retry_queue))
                self.queue = list(self.retry_queue)
                self.retry_queue = []
                self.retry_pass = True
                self.index = 0
                self._set_timer(600, self._next)
                return
            self._finish_all()
            return
        profile, sid, pid = self.queue[self.index]
        self.scan_pid = pid
        self.scan_retry = 0
        self._prepare_current(profile, sid, pid)

    def _disarm_hold(self):
        try:
            write_param(PARAM_HOLD_ENABLE, 0)
            write_param(PARAM_HOLD_PID, -1)
        except Exception as e:
            log("helper hold disarm failed: %s" % e)

    def _prepare_current(self, profile, sid, pid):
        self._disarm_hold()
        try:
            write_param(PARAM_ENABLE, 1)
            write_param(PARAM_PID, pid)
            write_param(PARAM_SID, sid)
        except Exception as e:
            self._fatal("Cannot set driver selector: %s" % e)
            return
        self.scan_retry = 0
        self.scan_had_source = False
        self.bootstrap_scan = False
        self.post_verify_info = None
        self["status"].setText("%d/%d  %s   hidden PID %d   source SID %d" %
                               (self.index + 1, len(self.queue), profile[0], pid, sid))
        source_ref = find_source_ref(sid, profile[1])
        if source_ref:
            if not self.first_source_transition_done:
                self.first_source_transition_done = True
                # The driver considers an active bridge live for 1000 ms after
                # its last inner packet.  When the scan starts from the same
                # outer SID, playService() alone may not retune, so the old
                # bridge is reused and candidate #1 never gets a fresh hit.
                # Stop it once and let it age past the stale window before
                # replaying the requested source.  This is helper-only: no
                # demux reset, CA reset, or decoder change is introduced.
                log("first carrier clean transition %s sid=%d pid=%d: stop current service; wait 1250ms before source activation" %
                    (profile[0], sid, pid))
                self["detail"].setText("Preparing first hidden carrier cleanly...")
                try:
                    self.session.nav.stopService()
                except Exception:
                    pass
                self._set_timer(1250, lambda: self._activate_source(profile, sid, pid, source_ref))
            else:
                self._activate_source(profile, sid, pid, source_ref)
        else:
            self["detail"].setText("Physical transponder is not in lamedb yet; bootstrap scan once...")
            log("carrier %s sid=%d pid=%d physical TP missing; bootstrap scan" % (profile[0], sid, pid))
            self.bootstrap_scan = True
            self.scan_hits_before = read_int(PARAM_HITS, 0)
            self._start_scan(profile, sid, pid)

    def _activate_source(self, profile, sid, pid, source_ref):
        self.scan_had_source = True
        self.bootstrap_scan = False
        self.source_hits_before = read_int(PARAM_HITS, 0)
        self.source_ready_before = read_int(PARAM_FORCE_READY, 0)
        self.source_inner_before = read_int(PARAM_INNER, 0)
        # First pass stays quick.  A genuine first-pass timeout is retried once
        # after the other carriers have exercised/warmed the normal CA path.
        self.source_wait_deadline = time.time() + (15.0 if self.retry_pass else 12.0)
        self["detail"].setText("Activating outer SID %d and waiting for hidden PID %d CW..." % (sid, pid))
        log("carrier %s sid=%d pid=%d activate source=%s hits=%d ready=%d inner=%d pass=%d" %
            (profile[0], sid, pid, source_ref, self.source_hits_before,
             self.source_ready_before, self.source_inner_before, 2 if self.retry_pass else 1))
        try:
            self.session.nav.playService(eServiceReference(source_ref))
        except Exception as e:
            log("source zap failed: %s" % e)
        self._set_timer(250, lambda: self._wait_source_ready(profile, sid, pid))

    def _wait_source_ready(self, profile, sid, pid):
        if self.cancelled:
            return
        hits = read_int(PARAM_HITS, 0)
        ready = read_int(PARAM_FORCE_READY, 0)
        last_pid = read_int(PARAM_LAST_PID, -1)
        inner = read_int(PARAM_INNER, 0)
        cw_ready = ready > self.source_ready_before
        decoded_new = hits > self.source_hits_before and last_pid == pid
        # V13.15.7: if this PID was already the confirmed persistent bridge
        # before the helper opened, e2_abertis_hits does not need to increment.
        # Prove it is really live by requiring its inner packet counter to move.
        decoded_live = last_pid == pid and inner > self.source_inner_before
        decoded = decoded_new or decoded_live
        if cw_ready or decoded:
            log("source ready %s sid=%d pid=%d cw_ready=%s decoded=%s live=%s hits=%d->%d ready=%d->%d inner=%d->%d last_pid=%d" %
                (profile[0], sid, pid, cw_ready, decoded, decoded_live,
                 self.source_hits_before, hits, self.source_ready_before, ready,
                 self.source_inner_before, inner, last_pid))
            try:
                # Arm before stopService(), because CA_SET_PID(remove)/CA_RESET
                # is the event that transfers the already-programmed DSC
                # channel to the helper-only short hold.
                write_param(PARAM_HOLD_PID, pid)
                write_param(PARAM_HOLD_ENABLE, 1)
            except Exception as e:
                self._fatal("Cannot arm helper CW handoff: %s" % e)
                return
            self.scan_hits_before = hits
            self.scan_retry = 0
            self["detail"].setText("CW ready; handing PID %d into inner scan..." % pid)
            try:
                self.session.nav.stopService()
            except Exception:
                pass
            self._set_timer(180, lambda: self._start_scan(profile, sid, pid))
            return
        if time.time() < self.source_wait_deadline:
            self._set_timer(250, lambda: self._wait_source_ready(profile, sid, pid))
            return
        log("source ready timeout %s sid=%d pid=%d hits=%d->%d ready=%d->%d inner=%d->%d last_pid=%d pass=%d" %
            (profile[0], sid, pid, self.source_hits_before, hits,
             self.source_ready_before, ready, self.source_inner_before, inner,
             last_pid, 2 if self.retry_pass else 1))
        self._disarm_hold()
        try:
            self.session.nav.stopService()
        except Exception:
            pass
        if not self.retry_pass:
            self.retry_queue.append((profile, sid, pid))
            log("defer %s sid=%d pid=%d to second pass" % (profile[0], sid, pid))
        else:
            self._record(False, profile, sid, pid, "outer SID did not activate selected hidden PID after retry")
        self.index += 1
        self._set_timer(500, self._next)

    def _start_scan(self, profile, sid, pid):
        if self.cancelled:
            return
        self._cleanup_scan()
        self.scan_found_services = []
        self.scan = eComponentScan()
        self.scan.statusChanged.get().append(self._scan_status)
        try:
            self.scan.newService.get().append(self._new_service)
        except Exception:
            pass
        self.scan.addInitial(build_satparm(profile))
        self["progress"].setValue(0)
        log("scan start feid=%d %s sid=%d pid=%d attempt=%d" %
            (self.feid, profile[0], sid, pid, self.scan_retry + 1))
        err = self.scan.start(self.feid, 0, 0)
        if err:
            log("scan start error=%s" % err)
            self._cleanup_scan()
            # A current service can own the only frontend.  Retry once after
            # stopping it; if the driver already saw the CW, its live bridge
            # can still be used, otherwise this carrier is reported failed.
            if self.scan_retry == 0:
                self.scan_retry = 1
                try:
                    self.session.nav.stopService()
                except Exception:
                    pass
                self._set_timer(250, lambda: self._start_scan(profile, sid, pid))
            else:
                self._record(False, profile, sid, pid, "scan-start-error")
                self.index += 1
                self._set_timer(200, self._next)

    def _new_service(self):
        if self.scan is None:
            return
        try:
            name = self.scan.getLastServiceName()
        except Exception:
            name = ""
        try:
            ref = self.scan.getLastServiceRef()
            refstr = _ref_string(ref)
        except Exception as e:
            log("new service ref read failed: %s" % e)
            return
        if not refstr:
            return
        name = _safe_service_name(name)
        item = (name, refstr)
        if item not in self.scan_found_services:
            self.scan_found_services.append(item)
            try:
                hidden_pid = int(self.queue[self.index][2])
            except Exception:
                hidden_pid = -1
            if not any(x[1] == refstr for x in self.all_found_services):
                self.all_found_services.append((name, refstr, hidden_pid))
            else:
                for old_name, old_ref, old_pid in self.all_found_services:
                    if old_ref == refstr and old_pid != hidden_pid:
                        log("WARNING service-ref collision ref=%s old_pid=%d new_pid=%d" %
                            (refstr, old_pid, hidden_pid))
                        break
            log("new service name=%r ref=%s hidden_pid=%d" % (name, refstr, hidden_pid))

    def _scan_status(self):
        if self.scan is None:
            return
        try:
            self["progress"].setValue(min(100, int(self.scan.getProgress())))
        except Exception:
            pass
        try:
            if not self.scan.isDone():
                return
        except Exception:
            return
        profile, sid, pid = self.queue[self.index]
        try:
            err = self.scan.getError()
        except Exception:
            err = -1
        try:
            num = self.scan.getNumServices()
        except Exception:
            num = -1
        self._cleanup_scan()
        self.post_verify_deadline = time.time() + 1.5
        self.post_verify_info = (profile, sid, pid, err, num, bool(self.bootstrap_scan), list(self.scan_found_services))
        self._verify_scan_result()

    def _verify_scan_result(self):
        if self.cancelled or not self.post_verify_info:
            return
        profile, sid, pid, err, num, was_bootstrap, found_services = self.post_verify_info
        hits_after = read_int(PARAM_HITS, 0)
        last_pid = read_int(PARAM_LAST_PID, -1)
        hidden_hit = hits_after > self.scan_hits_before and last_pid == pid
        if hidden_hit:
            log("scan done %s sid=%d pid=%d error=%s services=%s hidden_hit=True hits=%d->%d last_pid=%d" %
                (profile[0], sid, pid, err, num, self.scan_hits_before, hits_after, last_pid))
            self.post_verify_info = None
            self._disarm_hold()
            self._commit_found_services(profile, pid, found_services)
            self._record(True, profile, sid, pid, "%s services" % num)
            self.index += 1
            self._set_timer(250, self._next)
            return

        if time.time() < self.post_verify_deadline:
            self._set_timer(250, self._verify_scan_result)
            return

        log("scan done %s sid=%d pid=%d error=%s services=%s hidden_hit=False hits=%d->%d last_pid=%d bootstrap=%s" %
            (profile[0], sid, pid, err, num, self.scan_hits_before, hits_after, last_pid, was_bootstrap))
        self.post_verify_info = None
        self._disarm_hold()

        # A bootstrap pass only exists to put the physical RF transponder in
        # lamedb.  Once it is known, synthesize/locate the data-service ref and
        # activate the requested outer SID before doing the real inner scan.
        if was_bootstrap:
            source_ref = find_source_ref(sid, profile[1])
            if source_ref:
                self._activate_source(profile, sid, pid, source_ref)
                return

        self._record(False, profile, sid, pid, "no hidden bridge confirmation")
        self.index += 1
        self._set_timer(250, self._next)

    def _backup_lamedb_once(self, path):
        if self.lamedb_backup:
            return True
        try:
            backup = path + ".abertis-v13157-before-commit"
            shutil.copy2(path, backup)
            self.lamedb_backup = backup
            log("lamedb backup=%s" % backup)
            return True
        except Exception as e:
            log("lamedb backup failed path=%s error=%s" % (path, e))
            return False

    def _commit_found_services(self, profile, hidden_pid, found_services):
        """Fallback for Enigma2 scans that count the inner services but reject
        the reconstructed transport at channelDone().  Preserve the service
        identities emitted by eComponentScan, add only missing records, and
        attach the known Abertis data PID/CAID so a later zap can prime the
        same hidden PID through the normal Enigma2/OSCam path.
        """
        if not found_services:
            log("commit %s pid=%d: scan emitted no newService refs; nothing to persist" %
                (profile[0], hidden_pid))
            return

        path = _lamedb_path()
        try:
            with open(path, "r") as f:
                lines = [x.rstrip("\n") for x in f]
        except Exception as e:
            log("commit %s pid=%d: cannot read %s: %s" % (profile[0], hidden_pid, path, e))
            return
        if not lines:
            log("commit %s pid=%d: empty lamedb" % (profile[0], hidden_pid))
            return

        parsed = []
        for name, refstr in found_services:
            ident = _service_ref_parts(refstr)
            if not ident:
                log("commit skip unparsable ref=%s" % refstr)
                continue
            # Reject an all-unknown identity rather than risk corrupting the DB.
            if ident["tsid"] in (0xffff, 0xffffffff) or ident["onid"] in (0xffff, 0xffffffff):
                log("commit skip unresolved transport ref=%s" % refstr)
                continue
            parsed.append((name, refstr, ident))
        if not parsed:
            log("commit %s pid=%d: no safe DVB service refs" % (profile[0], hidden_pid))
            return

        header = lines[0].strip()
        is_v5 = "/5/" in header
        freq, sr = int(profile[1]), int(profile[2])
        rf = _find_rf_params_v5(lines, freq, sr) if is_v5 else _find_rf_params_v4(lines, freq, sr)
        if not rf:
            log("commit %s pid=%d: physical RF parameters not found in %s" % (profile[0], hidden_pid, path))
            return

        added_services = 0
        added_tps = 0
        # Work on a copy and perform one atomic replacement.
        out = list(lines)

        if is_v5:
            existing_tps = set()
            existing_svcs = set()
            for line in out:
                if line.startswith("t:"):
                    existing_tps.add(line.split(",", 1)[0].lower())
                elif line.startswith("s:"):
                    existing_svcs.add(line.split(",", 1)[0].lower())

            tp_lines = []
            svc_lines = []
            for name, refstr, ident in parsed:
                tpkey = "t:%08x:%04x:%04x" % (ident["ns"], ident["tsid"], ident["onid"])
                if tpkey.lower() not in existing_tps:
                    tp_lines.append(tpkey + "," + rf)
                    existing_tps.add(tpkey.lower())
                    added_tps += 1
                svckey = "s:%04x:%08x:%04x:%04x:%x:0:0" % (
                    ident["sid"], ident["ns"], ident["tsid"], ident["onid"], ident["stype"])
                # A lamedb may already contain the service with another type;
                # match the DVB identity first four fields as well.
                identity_prefix = "s:%04x:%08x:%04x:%04x:" % (
                    ident["sid"], ident["ns"], ident["tsid"], ident["onid"])
                if not any(x.startswith(identity_prefix.lower()) for x in existing_svcs):
                    qname = _safe_service_name(name).replace('"', "'")
                    svc_lines.append('%s,"%s",p:Abertis' % (svckey, qname))
                    existing_svcs.add(svckey.lower())
                    added_services += 1
                    self.committed_services.append((name, refstr, hidden_pid))

            if tp_lines:
                first_service = len(out)
                for i, line in enumerate(out):
                    if line.startswith("s:"):
                        first_service = i
                        break
                out[first_service:first_service] = tp_lines
            if svc_lines:
                out.extend(svc_lines)
        else:
            # v4 has explicit transponders/end and services/end sections.
            try:
                tp_start = out.index("transponders")
                tp_end = out.index("end", tp_start + 1)
                svc_start = out.index("services", tp_end + 1)
                svc_end = out.index("end", svc_start + 1)
            except Exception as e:
                log("commit %s pid=%d: malformed lamedb4: %s" % (profile[0], hidden_pid, e))
                return

            existing_tp_keys = set()
            i = tp_start + 1
            while i < tp_end:
                q = out[i].strip()
                if re.match(r"^[0-9a-fA-F]+:[0-9a-fA-F]+:[0-9a-fA-F]+$", q):
                    existing_tp_keys.add(q.lower())
                i += 1

            existing_service_identity = set()
            i = svc_start + 1
            while i < svc_end:
                q = out[i].strip()
                parts = q.split(":")
                if len(parts) >= 4 and all(re.match(r"^[0-9a-fA-F]+$", x or "x") for x in parts[:4]):
                    existing_service_identity.add(":".join(parts[:4]).lower())
                i += 1

            tp_insert = []
            svc_insert = []
            for name, refstr, ident in parsed:
                tpkey = "%08x:%04x:%04x" % (ident["ns"], ident["tsid"], ident["onid"])
                if tpkey.lower() not in existing_tp_keys:
                    tp_insert += [tpkey, "\t" + rf, "/"]
                    existing_tp_keys.add(tpkey.lower())
                    added_tps += 1
                skey = "%04x:%08x:%04x:%04x" % (
                    ident["sid"], ident["ns"], ident["tsid"], ident["onid"])
                if skey.lower() not in existing_service_identity:
                    svc_insert += [
                        "%s:%x:0:0" % (skey, ident["stype"]),
                        _safe_service_name(name),
                        "p:Abertis",
                    ]
                    existing_service_identity.add(skey.lower())
                    added_services += 1
                    self.committed_services.append((name, refstr, hidden_pid))

            if tp_insert:
                out[tp_end:tp_end] = tp_insert
                # service indexes moved by tp insertion
                shift = len(tp_insert)
                svc_start += shift
                svc_end += shift
            if svc_insert:
                out[svc_end:svc_end] = svc_insert

        if not added_services and not added_tps:
            log("commit %s pid=%d: all %d emitted services already present in lamedb" %
                (profile[0], hidden_pid, len(parsed)))
            return
        if not self._backup_lamedb_once(path):
            return
        tmp = path + ".abertis-v13157.tmp"
        try:
            with open(tmp, "w") as f:
                f.write("\n".join(out) + "\n")
            os.rename(tmp, path)
            # Do not reloadServicelist here.  Reloading the live Enigma2 DB
            # between Abertis carriers can invalidate service objects owned by
            # the running scan screen.  Commit to disk now and reload once at
            # _finish_all() after every carrier is complete.
            log("commit %s pid=%d: added_services=%d added_transponders=%d captured=%d" %
                (profile[0], hidden_pid, added_services, added_tps, len(parsed)))
        except Exception as e:
            log("commit %s pid=%d write failed: %s" % (profile[0], hidden_pid, e))
            try:
                if os.path.exists(tmp):
                    os.unlink(tmp)
            except Exception:
                pass

    def _ensure_bouquet_registered(self, master_path, bouquet_name, radio=False):
        try:
            line = '#SERVICE 1:7:%d:0:0:0:0:0:0:0:FROM BOUQUET "%s" ORDER BY bouquet' % (
                2 if radio else 1, bouquet_name)
            old = []
            if os.path.exists(master_path):
                with open(master_path, "r") as f:
                    old = [x.rstrip("\n") for x in f]
            if line not in old:
                old.append(line)
                tmp = master_path + ".abertis-v13157.tmp"
                with open(tmp, "w") as f:
                    f.write("\n".join(old) + "\n")
                os.rename(tmp, master_path)
        except Exception as e:
            log("bouquet register failed %s: %s" % (master_path, e))

    def _write_found_bouquets(self):
        if not self.all_found_services:
            log("bouquet: no captured services")
            return

        # Never create dead bouquet entries.  Only expose refs that are now
        # really present in lamedb (either saved by eDVBScan itself or by the
        # guarded fallback above).
        saved = set()
        path = _lamedb_path()
        try:
            with open(path, "r") as f:
                db_lines = [x.rstrip("\n") for x in f]
            is_v5 = bool(db_lines and "/5/" in db_lines[0])
            if is_v5:
                for line in db_lines:
                    if not line.startswith("s:"):
                        continue
                    head = line.split(",", 1)[0].split(":")
                    if len(head) >= 5:
                        try:
                            saved.add((int(head[1], 16), int(head[2], 16),
                                       int(head[3], 16), int(head[4], 16)))
                        except Exception:
                            pass
            else:
                in_services = False
                for line in db_lines:
                    q = line.strip()
                    if q == "services":
                        in_services = True
                        continue
                    if in_services and q == "end":
                        break
                    if not in_services:
                        continue
                    head = q.split(":")
                    if len(head) >= 4:
                        try:
                            saved.add((int(head[0], 16), int(head[1], 16),
                                       int(head[2], 16), int(head[3], 16)))
                        except Exception:
                            pass
        except Exception as e:
            log("bouquet: cannot verify lamedb services: %s" % e)

        tv = []
        radio = []
        seen = set()
        for name, refstr, hidden_pid in self.all_found_services:
            if refstr in seen:
                continue
            seen.add(refstr)
            ident = _service_ref_parts(refstr)
            if not ident:
                continue
            key = (ident["sid"], ident["ns"], ident["tsid"], ident["onid"])
            if key not in saved:
                log("bouquet skip unsaved ref=%s pid=%d" % (refstr, hidden_pid))
                continue
            row = (name, refstr, hidden_pid)
            if ident["stype"] in (2, 10):
                radio.append(row)
            else:
                tv.append(row)

        def write_one(filename, title, rows, radio_mode=False):
            if not rows:
                return 0
            path = "/etc/enigma2/" + filename
            lines = ["#NAME " + title]
            for name, refstr, hidden_pid in rows:
                lines.append("#SERVICE " + refstr)
                lines.append("#DESCRIPTION %s [Abertis PID %d]" % (_safe_service_name(name), hidden_pid))
            try:
                tmp = path + ".tmp"
                with open(tmp, "w") as f:
                    f.write("\n".join(lines) + "\n")
                os.rename(tmp, path)
                self._ensure_bouquet_registered(
                    "/etc/enigma2/bouquets.radio" if radio_mode else "/etc/enigma2/bouquets.tv",
                    filename, radio=radio_mode)
                log("bouquet wrote %s services=%d" % (path, len(rows)))
                return len(rows)
            except Exception as e:
                log("bouquet write failed %s: %s" % (path, e))
                return 0

        tvn = write_one("userbouquet.hispasat_abertis_native.tv",
                        "Hispasat 30W - Abertis Native", tv, False)
        rdn = write_one("userbouquet.hispasat_abertis_native.radio",
                        "Hispasat 30W - Abertis Native Radio", radio, True)
        try:
            eDVBDB.getInstance().reloadBouquets()
        except Exception as e:
            log("reloadBouquets failed: %s" % e)
        log("bouquet complete tv=%d radio=%d captured=%d" % (tvn, rdn, len(self.all_found_services)))

    def _cleanup_scan(self):
        if self.scan is None:
            return
        try:
            self.scan.statusChanged.get().remove(self._scan_status)
        except Exception:
            pass
        try:
            self.scan.newService.get().remove(self._new_service)
        except Exception:
            pass
        self.scan = None

    def _record(self, ok, profile, sid, pid, note):
        self.results.append((ok, profile[0], sid, pid, note))
        self["detail"].setText(("OK" if ok else "MISS") + "  %s PID %d / SID %d  %s" %
                               (profile[0], pid, sid, note))

    def _restore(self):
        self._cleanup_scan()
        try:
            self.timer.stop()
        except Exception:
            pass
        try:
            write_param(PARAM_HOLD_ENABLE, 0)
            write_param(PARAM_HOLD_PID, -1)
            write_param(PARAM_PID, self.saved_pid)
            write_param(PARAM_SID, self.saved_sid)
            write_param(PARAM_ENABLE, self.saved_enable)
        except Exception as e:
            log("restore params failed: %s" % e)
        try:
            if self.saved_service:
                self.session.nav.playService(self.saved_service)
        except Exception:
            pass

    def _finish_all(self):
        try:
            eDVBDB.getInstance().reloadServicelist()
            log("final service-list reload complete")
        except Exception as e:
            log("final reloadServicelist failed: %s" % e)
        self._write_found_bouquets()
        self._restore()
        ok = sum(1 for x in self.results if x[0])
        fail = len(self.results) - ok
        log("finished ok=%d miss=%d" % (ok, fail))
        text = "Hispasat Abertis scan finished.\n\nConfirmed hidden muxes: %d\nMissed: %d\n\nLog: %s" % (ok, fail, LOGFILE)
        self.session.openWithCallback(lambda *a: self.close(), MessageBox, text, MessageBox.TYPE_INFO)

    def _fatal(self, text):
        log("FATAL " + text)
        self._restore()
        self.session.openWithCallback(lambda *a: self.close(), MessageBox, text, MessageBox.TYPE_ERROR)

    def cancel(self):
        self.cancelled = True
        self._restore()
        self.close()



_ABERTIS_ZAP = None


def _norm_ref(ref):
    try:
        s = ref.toString()
    except Exception:
        s = str(ref or "")
    # Ignore display/description suffix differences and normalize hex case.
    return s.strip().rstrip(":").upper()


def _carrier_for_pid(pid):
    try:
        pid = int(pid)
    except Exception:
        return None
    for profile in PROFILES:
        for sid, hp in profile[4]:
            if int(hp) == pid:
                return profile, int(sid)
    return None


class AbertisZapHandoff(object):
    """Prime the encrypted outer Abertis carrier before a normal inner zap.

    Inner Abertis MPEG-TS services are legitimately signalled as FTA, so
    Enigma2/OSCam will not create a CA session for them.  The outer data service
    is BISS scrambled.  V13.15.7 already knows how to hold its programmed DSC
    channel across a same-RF retune.  This wrapper only automates the proven
    sequence used by the scanner:

        target inner service -> outer source SID -> wait for CW/decoded hit
        -> arm helper hold -> stop outer -> 180 ms -> real inner service

    No lamedb PID/CA metadata is modified.
    """
    def __init__(self, session):
        self.session = session
        self.nav = session.nav
        self.orig_play = self.nav.playService
        self.timer = eTimer()
        timer_connect(self.timer, self._timer_fired)
        self.timer_fn = None
        self.busy = False
        self.pending = None
        self.service_map = {}
        self._load_map()
        try:
            # Instance-level wrapper keeps the original bound method intact and
            # avoids depending on Navigation.playService's image-specific
            # signature.  *args/**kwargs are replayed only for the real target.
            self.nav.playService = self.playService
            log("zap handoff v4 installed mapped_services=%d" % len(self.service_map))
        except Exception as e:
            log("zap handoff v4 install failed: %s" % e)

    def _schedule(self, ms, fn):
        self.timer_fn = fn
        try:
            self.timer.stop()
        except Exception:
            pass
        try:
            self.timer.start(int(ms), True)
        except Exception:
            self.timer.start(int(ms))

    def _timer_fired(self):
        fn = self.timer_fn
        self.timer_fn = None
        if fn:
            try:
                fn()
            except Exception as e:
                log("zap handoff timer error: %s" % e)
                self._fallback_target()

    def _load_map(self):
        """Read the helper bouquet: SERVICE line + following Abertis PID tag."""
        path = "/etc/enigma2/userbouquet.hispasat_abertis_native.tv"
        result = {}
        try:
            lines = open(path, "r").read().splitlines()
        except Exception as e:
            log("zap handoff map unavailable %s: %s" % (path, e))
            self.service_map = result
            return
        last_ref = None
        for raw in lines:
            line = raw.strip()
            if line.startswith("#SERVICE "):
                last_ref = line[len("#SERVICE "):].strip()
                continue
            if line.startswith("#DESCRIPTION ") and last_ref:
                m = re.search(r"\[Abertis PID\s+([0-9]+)\]", line)
                if m:
                    pid = int(m.group(1))
                    c = _carrier_for_pid(pid)
                    if c:
                        result[_norm_ref(last_ref)] = pid
                last_ref = None
        self.service_map = result

    def refresh_map(self):
        self._load_map()
        log("zap handoff map refreshed mapped_services=%d" % len(self.service_map))

    def playService(self, ref, *args, **kwargs):
        if self.busy:
            return self.orig_play(ref, *args, **kwargs)

        # The scan may have just rewritten the bouquet since session start.
        key = _norm_ref(ref)
        pid = self.service_map.get(key)
        if pid is None:
            return self.orig_play(ref, *args, **kwargs)

        carrier = _carrier_for_pid(pid)
        if not carrier:
            return self.orig_play(ref, *args, **kwargs)
        profile, sid = carrier
        source_ref = find_source_ref(sid, profile[1])
        if not source_ref:
            log("zap handoff target=%s pid=%d: outer source SID %d not found; normal play" %
                (key, pid, sid))
            return self.orig_play(ref, *args, **kwargs)

        try:
            write_param(PARAM_ENABLE, 1)
            write_param(PARAM_PID, pid)
            write_param(PARAM_SID, sid)
        except Exception as e:
            log("zap handoff selector failed target=%s pid=%d: %s" % (key, pid, e))
            return self.orig_play(ref, *args, **kwargs)

        self.busy = True
        self.pending = {
            "ref": ref, "args": args, "kwargs": kwargs,
            "profile": profile, "sid": sid, "pid": pid,
            "hits": read_int(PARAM_HITS, 0),
            "ready": read_int(PARAM_FORCE_READY, 0),
            "inner": read_int(PARAM_INNER, 0),
            "deadline": time.time() + 8.0,
        }
        log("zap handoff PRIME target=%s profile=%s sid=%d pid=%d source=%s hits=%d ready=%d inner=%d" %
            (key, profile[0], sid, pid, source_ref,
             self.pending["hits"], self.pending["ready"], self.pending["inner"]))
        try:
            # Do not propagate target-specific parental/force arguments to the
            # invisible donor service; they belong to the requested service.
            ret = self.orig_play(eServiceReference(source_ref))
        except Exception as e:
            log("zap handoff outer play failed: %s" % e)
            return self._fallback_target()
        self._schedule(100, self._poll_ready)
        return ret

    def _poll_ready(self):
        p = self.pending
        if not self.busy or not p:
            return
        hits = read_int(PARAM_HITS, 0)
        ready = read_int(PARAM_FORCE_READY, 0)
        inner = read_int(PARAM_INNER, 0)
        last_pid = read_int(PARAM_LAST_PID, -1)
        cw_ready = ready > p["ready"]
        decoded_new = hits > p["hits"] and last_pid == p["pid"]
        decoded_live = last_pid == p["pid"] and inner > p["inner"]
        if cw_ready or decoded_new or decoded_live:
            log("zap handoff READY profile=%s sid=%d pid=%d cw=%s hit=%s live=%s hits=%d->%d ready=%d->%d inner=%d->%d" %
                (p["profile"][0], p["sid"], p["pid"], cw_ready, decoded_new,
                 decoded_live, p["hits"], hits, p["ready"], ready, p["inner"], inner))
            try:
                # Must be armed BEFORE CA_SET_PID(remove) caused by stopService.
                write_param(PARAM_HOLD_PID, p["pid"])
                write_param(PARAM_HOLD_ENABLE, 1)
            except Exception as e:
                log("zap handoff arm failed: %s" % e)
                return self._fallback_target()
            try:
                self.nav.stopService()
            except Exception as e:
                log("zap handoff donor stop error: %s" % e)
            self._schedule(180, self._play_target)
            return
        if time.time() < p["deadline"]:
            self._schedule(100, self._poll_ready)
            return
        log("zap handoff TIMEOUT profile=%s sid=%d pid=%d hits=%d->%d ready=%d->%d inner=%d->%d last_pid=%d" %
            (p["profile"][0], p["sid"], p["pid"], p["hits"], hits,
             p["ready"], ready, p["inner"], inner, last_pid))
        self._fallback_target()

    def _play_target(self):
        p = self.pending
        if not p:
            self.busy = False
            return False
        try:
            before_reuse = read_int(PARAM_HOLD_REUSES, 0)
            log("zap handoff TARGET profile=%s sid=%d pid=%d hold_reuses=%d ref=%s" %
                (p["profile"][0], p["sid"], p["pid"], before_reuse, _norm_ref(p["ref"])))
            ret = self.orig_play(p["ref"], *p["args"], **p["kwargs"])
        except Exception as e:
            log("zap handoff target play failed: %s" % e)
            ret = False
        self.pending = None
        self.busy = False
        return ret

    def _fallback_target(self):
        p = self.pending
        self.pending = None
        self.busy = False
        if not p:
            return False
        try:
            return self.orig_play(p["ref"], *p["args"], **p["kwargs"])
        except Exception as e:
            log("zap handoff fallback failed: %s" % e)
            return False


def sessionstart(reason, session=None, **kwargs):
    global _ABERTIS_ZAP
    if reason != 0 or session is None:
        return
    try:
        _ABERTIS_ZAP = AbertisZapHandoff(session)
    except Exception as e:
        log("zap handoff sessionstart failed: %s" % e)

def choice_callback(session, choice):
    if not choice:
        return
    mode = choice[1]
    session.open(AbertisScanRunner, mode)


def main(session, **kwargs):
    choices = [
        ("TEST: 11222H PID 2025 + 2026 only", "test"),
        ("11222H - all 6 hidden carriers", "profile:11222H"),
        ("ALL Hispasat 30W - 38 hidden carriers", "all"),
    ]
    for p in PROFILES[1:]:
        choices.append(("%s - %d hidden carriers" % (p[0], len(p[4])), "profile:" + p[0]))
    session.openWithCallback(lambda c: choice_callback(session, c), ChoiceBox,
                             title="Hispasat Abertis hidden-carrier scan", list=choices)


def Plugins(**kwargs):
    return [
        PluginDescriptor(name="Hispasat Abertis Scan",
                         description="Scan Hispasat 30W Abertis hidden carriers one by one",
                         where=PluginDescriptor.WHERE_PLUGINMENU,
                         fnc=main),
        PluginDescriptor(where=PluginDescriptor.WHERE_SESSIONSTART,
                         fnc=sessionstart),
    ]
