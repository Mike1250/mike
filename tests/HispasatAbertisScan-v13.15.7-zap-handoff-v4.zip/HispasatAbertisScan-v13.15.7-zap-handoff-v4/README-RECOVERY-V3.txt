Hispasat Abertis Scan V13.15.7 - recovery-safe v3
=================================================

Purpose
-------
Recover safely from channel-ca-v2.  That build incorrectly wrote the Abertis
outer hidden PID as lamedb c:15xxxx plus C:2600.  Enigma2 interpreted c:15 as
an elementary/audio stream PID, causing the hidden outer PID (for example
0x07e9) to be opened as service audio and destabilizing playback/Enigma2.

This build
----------
- DOES NOT write c:15xxxx or C:2600 metadata.
- Keeps the proven first-candidate 1250 ms clean transition.
- Keeps normal service-name/channel commit and bouquet creation.
- Does not reload the live Enigma2 service database between carriers.
- Reloads the service database once, only after the complete scan finishes.
- Does not modify aml_hardware_dmx or the Abertis decoder/CA implementation.

Recovery from channel-ca-v2
---------------------------
Run recover_from_ca_v2.sh before restarting Enigma2.  The script makes a
backup of the current lamedb, then surgically removes only the c:15xxxx and
C:2600 pair for the known Abertis hidden PIDs inserted by channel-ca-v2.
It does NOT restore an old full lamedb and therefore does not discard channels
that were learned after the earlier backup.

Install
-------
  sh recover_from_ca_v2.sh
  sh install.sh
  restart Enigma2

The OSCam/playback handoff is intentionally NOT solved in lamedb metadata in
this recovery build.  That will be handled separately after Enigma2 is stable.
