#!/bin/sh
set -e
SRC="$(dirname "$0")/usr/lib/enigma2/python/Plugins/Extensions/HispasatAbertisScan"
DST="/usr/lib/enigma2/python/Plugins/Extensions/HispasatAbertisScan"
mkdir -p "$DST"
cp -f "$SRC"/*.py "$DST"/
chmod 644 "$DST"/*.py
rm -f "$DST"/*.pyc "$DST"/__pycache__/* 2>/dev/null || true
echo "Installed Hispasat Abertis Scan V13.15.7 zap handoff v4. Restart Enigma2 to load session hook."
