Hispasat Abertis Scan V13.15.7 - zap handoff v4
=================================================

Purpose
-------
Recover safely from channel-ca-v2.  That build incorrectly wrote the Abertis
outer hidden PID as lamedb c:15xxxx plus C:2600.  Enigma2 interpreted c:15 as
an elementary/audio stream PID, causing the hidden outer PID (for example
0x07e9) to be opened as service audio and destabilizing playback/Enigma2.

This build
----------
- DOES NOT write c:15xxxx or C:2600 metadata.
- Keeps the proven first-candidate 1250 ms clean transition.
- Keeps normal service-name/channel commit and bouquet creation.
- Does not reload the live Enigma2 service database between carriers.
- Reloads the service database once, only after the complete scan finishes.
- Does not modify aml_hardware_dmx or the Abertis decoder/CA implementation.

Recovery from channel-ca-v2
---------------------------
Run recover_from_ca_v2.sh before restarting Enigma2.  The script makes a
backup of the current lamedb, then surgically removes only the c:15xxxx and
C:2600 pair for the known Abertis hidden PIDs inserted by channel-ca-v2.
It does NOT restore an old full lamedb and therefore does not discard channels
that were learned after the earlier backup.

Install
-------
  sh recover_from_ca_v2.sh
  sh install.sh
  restart Enigma2

The OSCam/playback handoff is intentionally NOT solved in lamedb metadata in
this recovery build.  That will be handled separately after Enigma2 is stable.

V4 AUTOMATIC OSCAM ZAP HANDOFF
------------------------------
The inner Abertis services remain normal/FTA DVB services in lamedb.  At Enigma2
session start, the plugin reads userbouquet.hispasat_abertis_native.tv and maps
its normal service references to their hidden Abertis PID.  When one of these
services is opened from ANY bouquet/satellite list, playService is intercepted:
outer source SID -> OSCam CW -> V13.15.7 helper DSC hold -> same-RF target zap.
No c:15/C:2600 metadata is written to inner services.
Runtime diagnostics: /tmp/hispasat_abertis_scan.log
Expected: "zap handoff PRIME", "zap handoff READY", "zap handoff TARGET" and
kernel "E2_ABERTIS_HELPER... reuse DSC..." followed by "CW-ready".
