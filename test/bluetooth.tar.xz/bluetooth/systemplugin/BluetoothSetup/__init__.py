# Generic BlueZ Bluetooth Setup for Enigma2/OpenATV.
# Replaces the DreamBLE-specific UI while keeping the same plugin path/class.
