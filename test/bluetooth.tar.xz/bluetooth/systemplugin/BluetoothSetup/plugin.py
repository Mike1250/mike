from __future__ import absolute_import

import os
import re
import shlex

from enigma import eConsoleAppContainer, eTimer

from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.MenuList import MenuList
from Components.Sources.StaticText import StaticText
from Plugins.Plugin import PluginDescriptor
from Screens.ChoiceBox import ChoiceBox
from Screens.Console import Console
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen


PLUGIN_VERSION = "1.0.4"
BTCTL_CANDIDATES = (
    "/usr/bin/bluetoothctl", "/usr/sbin/bluetoothctl",
    "/bin/bluetoothctl", "/sbin/bluetoothctl",
)
BTD_CANDIDATES = (
    "/usr/libexec/bluetooth/bluetoothd",
    "/usr/lib/bluetooth/bluetoothd",
    "/usr/sbin/bluetoothd", "/usr/bin/bluetoothd",
    "/sbin/bluetoothd", "/bin/bluetoothd",
)
MAC_RE = re.compile(r"(?:[0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}")


def _which_fast(candidates, name=None):
    """Find an executable without spawning a subprocess (safe on E2 UI thread)."""
    for path in candidates:
        if os.path.isfile(path) and os.access(path, os.X_OK):
            return path
    if name:
        for directory in os.environ.get("PATH", "/usr/bin:/usr/sbin:/bin:/sbin").split(":"):
            path = os.path.join(directory or ".", name)
            if os.path.isfile(path) and os.access(path, os.X_OK):
                return path
    return None


def _hci_nodes():
    try:
        return sorted(x for x in os.listdir("/sys/class/bluetooth") if x.startswith("hci"))
    except Exception:
        return []


def _q(value):
    return shlex.quote(str(value))


class BluetoothSetup(Screen):
    """Generic BlueZ Bluetooth setup for Enigma2/OpenATV.

    v1.0.4 rule: NO subprocess or bluetoothctl call is allowed on the Enigma2
    UI thread. Everything that can wait on D-Bus/BlueZ runs through
    eConsoleAppContainer. Startup self-repairs D-Bus/BlueZ and pairing keeps
    discovery active so BLE remotes can pair/connect reliably.
    """

    skin = """
    <screen name="GenericBluetoothSetup" position="center,center" size="1120,650" title="Bluetooth Setup">
        <widget source="titleText" render="Label" position="30,18" size="1060,46" font="Regular;34" />
        <widget name="status" position="30,68" size="1060,80" font="Regular;22" />
        <widget name="list" position="30,155" size="1060,385" scrollbarMode="showOnDemand" />
        <widget source="key_red" render="Label" position="30,570" size="245,45" font="Regular;22" halign="center" />
        <widget source="key_green" render="Label" position="300,570" size="245,45" font="Regular;22" halign="center" />
        <widget source="key_yellow" render="Label" position="575,570" size="245,45" font="Regular;22" halign="center" />
        <widget source="key_blue" render="Label" position="845,570" size="245,45" font="Regular;22" halign="center" />
    </screen>
    """

    def __init__(self, session, *args, **kwargs):
        Screen.__init__(self, session)
        self.setTitle("Bluetooth Setup")
        self["titleText"] = StaticText("Generic Bluetooth Setup  v%s" % PLUGIN_VERSION)
        self["status"] = Label("Opening Bluetooth Setup...")
        self["list"] = MenuList([])
        self["key_red"] = StaticText("Close")
        self["key_green"] = StaticText("Scan")
        self["key_yellow"] = StaticText("Adapter")
        self["key_blue"] = StaticText("Actions")

        self.btctl = _which_fast(BTCTL_CANDIDATES, "bluetoothctl")
        self.bluetoothd = _which_fast(BTD_CANDIDATES, "bluetoothd")
        self.hcis = _hci_nodes()
        self.controllers = []
        self.controller = None
        self.devices = []
        self.daemon_running = False
        self.dbus_present = False

        self.busy = False
        self.console = None
        self.console_output = []
        self.pending_done = None
        self.pending_refresh = False
        self.scan_discovered = []

        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions", "DirectionActions"],
            {
                "cancel": self.close,
                "red": self.close,
                "green": self.scan,
                "yellow": self.yellowAction,
                "blue": self.deviceActions,
                "ok": self.deviceActions,
                "up": self["list"].up,
                "down": self["list"].down,
                "left": self["list"].pageUp,
                "right": self["list"].pageDown,
            },
            -1,
        )

        self.startTimer = eTimer()
        try:
            self.startTimer.callback.append(self._deferredStart)
        except Exception:
            self.startTimer_conn = self.startTimer.timeout.connect(self._deferredStart)
        self.onLayoutFinish.append(self._layoutReady)

    # ------------------------------------------------------------------
    # Immediate/UI-thread work only.  These functions never spawn a process.
    # ------------------------------------------------------------------

    def _layoutReady(self):
        self._updateImmediateStatus()
        try:
            self.startTimer.start(100, True)
        except TypeError:
            self.startTimer.start(100)

    def _deferredStart(self):
        try:
            self.startTimer.stop()
        except Exception:
            pass
        self.refresh()

    def _updateImmediateStatus(self):
        self.btctl = _which_fast(BTCTL_CANDIDATES, "bluetoothctl")
        self.bluetoothd = _which_fast(BTD_CANDIDATES, "bluetoothd")
        self.hcis = _hci_nodes()
        hci_text = ", ".join(self.hcis) if self.hcis else "none"
        if not self.btctl:
            self["status"].setText(
                "Linux controller(s): %s\nBlueZ tools are missing (bluetoothctl not found). Press YELLOW to install BlueZ." % hci_text
            )
            self["key_yellow"].setText("Install BlueZ")
        else:
            self["status"].setText(
                "Linux controller(s): %s\nChecking BlueZ in background..." % hci_text
            )
            self["key_yellow"].setText("Adapter")

    # ------------------------------------------------------------------
    # Async backend discovery
    # ------------------------------------------------------------------

    def _timed_shell_prefix(self):
        # Portable shell helper. It prefers coreutils/busybox timeout. If timeout
        # is unavailable the command still runs asynchronously, so Enigma2 UI
        # remains responsive.
        return r'''
gb_run() {
    secs="$1"; shift
    if command -v timeout >/dev/null 2>&1; then
        timeout "$secs" "$@"
    else
        "$@"
    fi
}
'''

    def _repair_shell(self):
        """Conservative OpenATV/BlueZ self-repair, always async."""
        btd = self.bluetoothd or ""
        script = r'''
set +e
LOG=/tmp/generic-bluetooth-repair.log
: > "$LOG"
echo "[repair] begin $(date 2>/dev/null || true)" >> "$LOG"

# The target OpenATV image had /usr and /usr/share at 2770. dbus-daemon
# drops privileges and then cannot traverse them to reload BlueZ policy.
# Only add missing world read/execute permissions; preserve all existing bits.
for d in /usr /usr/share; do
    [ -d "$d" ] && chmod o+rx "$d" 2>>"$LOG" || true
done
for d in /usr/share/dbus-1 /usr/share/dbus-1/system.d /etc/dbus-1 /etc/dbus-1/system.d; do
    [ -d "$d" ] && chmod a+rx "$d" 2>>"$LOG" || true
done
for f in /usr/share/dbus-1/system.conf /usr/share/dbus-1/system.d/bluetooth.conf; do
    [ -f "$f" ] && chmod a+r "$f" 2>>"$LOG" || true
done

# Reload the actual system-bus policy.
if command -v dbus-send >/dev/null 2>&1; then
    if ! dbus-send --system --print-reply \
        --dest=org.freedesktop.DBus /org/freedesktop/DBus \
        org.freedesktop.DBus.ReloadConfig >>"$LOG" 2>&1; then
        P="$(pidof dbus-daemon 2>/dev/null || true)"
        if [ -n "$P" ]; then
            kill -HUP $P 2>>"$LOG" || true
            sleep 1
            dbus-send --system --print-reply \
                --dest=org.freedesktop.DBus /org/freedesktop/DBus \
                org.freedesktop.DBus.ReloadConfig >>"$LOG" 2>&1 || true
        fi
    fi
fi

# Start BlueZ via the image's own SysV service.
if [ -x /etc/init.d/bluetooth ]; then
    /etc/init.d/bluetooth start >>"$LOG" 2>&1 || true
fi
sleep 1
'''
        if btd:
            script += '''
if command -v dbus-send >/dev/null 2>&1; then
    if ! dbus-send --system --print-reply --dest=org.freedesktop.DBus /org/freedesktop/DBus org.freedesktop.DBus.NameHasOwner string:org.bluez 2>/dev/null | grep -q 'boolean true'; then
        (%s -n >>/tmp/generic-bluetoothd.log 2>&1) &
        sleep 2
    fi
fi
''' % _q(btd)
        script += r'''
echo "[repair] end" >> "$LOG"
'''
        return script

    def refresh(self):
        self._updateImmediateStatus()
        if not self.btctl:
            self.controllers = []
            self.controller = None
            self.devices = []
            self["list"].setList([])
            return
        if self.busy:
            self.pending_refresh = True
            return
        self._probeBlueZ()

    def _probeBlueZ(self):
        self.btctl = _which_fast(BTCTL_CANDIDATES, "bluetoothctl")
        self.bluetoothd = _which_fast(BTD_CANDIDATES, "bluetoothd")
        if not self.btctl:
            self.refresh()
            return

        cmd = self._timed_shell_prefix() + self._repair_shell() + r'''
echo "__GBT_DBUS__ $( ( [ -S /run/dbus/system_bus_socket ] || [ -S /var/run/dbus/system_bus_socket ] ) && echo yes || echo no )"
echo "__GBT_BLUEZ_OWNER__ $(dbus-send --system --print-reply --dest=org.freedesktop.DBus /org/freedesktop/DBus org.freedesktop.DBus.NameHasOwner string:org.bluez 2>/dev/null | grep -q 'boolean true' && echo yes || echo no)"
echo "__GBT_LIST_BEGIN__"
gb_run 6 ''' + _q(self.btctl) + r''' list 2>&1
echo "__GBT_LIST_END__"
'''
        self._async(cmd, self._probeDone, "Repairing/checking Bluetooth backend...")

    def _probeDone(self, rc, output):
        self.daemon_running = False
        self.dbus_present = False
        self.controllers = []

        for line in (output or "").splitlines():
            if line.startswith("__GBT_DBUS__"):
                self.dbus_present = line.split(None, 1)[1].strip() == "yes" if len(line.split(None, 1)) > 1 else False
            elif line.startswith("__GBT_BLUEZ_OWNER__"):
                tail = line[len("__GBT_BLUEZ_OWNER__"):].strip()
                self.daemon_running = tail == "yes"

        section = self._section(output, "__GBT_LIST_BEGIN__", "__GBT_LIST_END__")
        for raw in section.splitlines():
            line = self._clean_bt_line(raw)
            if not line.startswith("Controller "):
                continue
            m = MAC_RE.search(line)
            if not m:
                continue
            mac = m.group(0).upper()
            tail = line[m.end():].strip()
            default = "[default]" in tail
            name = tail.replace("[default]", "").strip() or mac
            self.controllers.append({"address": mac, "name": name, "default": default})

        if self.controllers:
            old = self.controller.get("address") if self.controller else None
            self.controller = next((x for x in self.controllers if x["address"] == old), None)
            if not self.controller:
                self.controller = next((x for x in self.controllers if x["default"]), self.controllers[0])
            self._prepareController()
            return

        self.controller = None
        self.devices = []
        self["list"].setList([])
        self._renderStatus()

    def _prepareController(self):
        if not self.btctl or not self.controller:
            self._renderStatus()
            return
        script = "select %s\npower on\npairable on\nquit\n" % self.controller["address"]
        inner = "printf %s | %s" % (_q(script), _q(self.btctl))
        cmd = self._timed_shell_prefix() + "\ngb_run 7 /bin/sh -c %s 2>&1\n" % _q(inner)
        self._async(cmd, self._prepareControllerDone, "Powering and enabling pairing on adapter...")

    def _prepareControllerDone(self, rc, output):
        self._queryDevices()

    def _queryDevices(self):
        if not self.btctl or not self.controller:
            self._renderStatus()
            return
        script = "select %s\ndevices\nquit\n" % self.controller["address"]
        interactive = "printf %s | %s" % (_q(script), _q(self.btctl))
        cmd = self._timed_shell_prefix() + "\n"
        cmd += "echo __GBT_DEV_BEGIN__\n"
        cmd += "gb_run 6 %s devices 2>&1\n" % _q(self.btctl)
        cmd += "gb_run 6 /bin/sh -c %s 2>&1\n" % _q(interactive)
        cmd += "echo __GBT_DEV_END__\n"
        self._async(cmd, self._devicesDone, "Reading discovered Bluetooth devices...")

    def _parseDeviceLines(self, text):
        devices = []
        seen = set()
        for raw in (text or "").splitlines():
            line = self._clean_bt_line(raw)
            if "Device " not in line:
                continue
            m = MAC_RE.search(line)
            if not m:
                continue
            mac = m.group(0).upper()
            tail = line[m.end():].strip()
            name = tail or mac
            if "Name:" in tail:
                name = tail.split("Name:", 1)[1].strip() or mac
            elif tail.startswith("RSSI:") or tail.startswith("ManufacturerData") or tail.startswith("TxPower:"):
                name = mac
            name = re.sub(r"\x1b\[[0-9;]*[A-Za-z]", "", name).strip() or mac
            if mac in seen:
                for d in devices:
                    if d["address"] == mac and d["name"] == mac and name != mac:
                        d["name"] = name
                continue
            seen.add(mac)
            devices.append({"address": mac, "name": name})
        return devices

    def _devicesDone(self, rc, output):
        section = self._section(output, "__GBT_DEV_BEGIN__", "__GBT_DEV_END__")
        merged = {}
        order = []
        for d in self._parseDeviceLines(section) + list(self.scan_discovered):
            mac = d["address"]
            if mac not in merged:
                merged[mac] = dict(d)
                order.append(mac)
            elif merged[mac].get("name") == mac and d.get("name") and d.get("name") != mac:
                merged[mac]["name"] = d["name"]
        self.devices = [merged[x] for x in order]
        self["list"].setList(["%-42s  %s" % (d["name"][:42], d["address"]) for d in self.devices])
        self._renderStatus()

    def _renderStatus(self):
        hci_text = ", ".join(_hci_nodes()) if _hci_nodes() else "none"
        adapter = "%s (%s)" % (self.controller["name"], self.controller["address"]) if self.controller else "none"
        btd_path = self.bluetoothd or "not found"
        self["status"].setText(
            "Adapter: %s    HCI: %s\nBlueZ: %s    D-Bus: %s    Devices: %d"
            % (adapter, hci_text, "running" if self.daemon_running else "stopped/missing", "OK" if self.dbus_present else "missing", len(self.devices))
        )
        if not self.daemon_running and self.btctl:
            # Keep this compact; detailed daemon diagnostics are in /tmp.
            self["status"].setText(
                "HCI: %s    bluetoothctl: installed\nbluetoothd: stopped/missing (%s). Check /tmp/generic-bluetoothd.log"
                % (hci_text, btd_path)
            )

    @staticmethod
    def _section(text, begin, end):
        text = text or ""
        a = text.find(begin)
        if a < 0:
            return ""
        a += len(begin)
        b = text.find(end, a)
        return text[a:] if b < 0 else text[a:b]

    @staticmethod
    def _clean_bt_line(line):
        # Strip common ANSI/color/control sequences from bluetoothctl output.
        line = re.sub(r"\x1b\[[0-9;?]*[ -/]*[@-~]", "", line or "")
        return line.strip()

    # ------------------------------------------------------------------
    # UI actions
    # ------------------------------------------------------------------

    def yellowAction(self):
        self.btctl = _which_fast(BTCTL_CANDIDATES, "bluetoothctl")
        if not self.btctl:
            self.installBlueZ()
        else:
            self.chooseAdapter()

    def chooseAdapter(self):
        if not self.controllers:
            self.session.open(MessageBox, "No BlueZ controller is available yet. The background check is still running or bluetoothd is not active.", type=MessageBox.TYPE_INFO, timeout=6)
            self.refresh()
            return
        choices = [
            ("%s  %s%s" % (x["name"], x["address"], "  [default]" if x["default"] else ""), x["address"])
            for x in self.controllers
        ]
        self.session.openWithCallback(self._adapterChosen, ChoiceBox, title="Select Bluetooth adapter", list=choices)

    def _adapterChosen(self, answer):
        if not answer:
            return
        addr = answer[1]
        self.controller = next((x for x in self.controllers if x["address"] == addr), None)
        self._queryDevices()

    def installBlueZ(self):
        if self.busy:
            return
        opkg = _which_fast(("/usr/bin/opkg", "/usr/bin/opkg-cl", "/bin/opkg", "/sbin/opkg"), "opkg")
        if not opkg:
            self.session.open(MessageBox, "opkg is not available. Install BlueZ manually (package usually named bluez5).", type=MessageBox.TYPE_ERROR)
            return
        msg = "Install the standard BlueZ userspace from the configured OpenATV feed?\n\nThis does not change your kernel or Bluetooth driver."
        self.session.openWithCallback(self._installConfirmed, MessageBox, msg, type=MessageBox.TYPE_YESNO, default=True)

    def _installConfirmed(self, yes):
        if not yes:
            return
        cmd = r'''
set +e
echo "[GenericBluetooth] BlueZ installation"
echo "[GenericBluetooth] Existing Linux controllers:"
ls -1 /sys/class/bluetooth 2>/dev/null || true
echo
if command -v bluetoothctl >/dev/null 2>&1; then
    echo "[GenericBluetooth] bluetoothctl is already installed."
else
    for p in bluez5 packagegroup-base-bluetooth bluez bluez-utils; do
        echo
        echo "[GenericBluetooth] trying package: $p"
        opkg install "$p"
        command -v bluetoothctl >/dev/null 2>&1 && break
    done
fi
if [ -x /etc/init.d/dbus ]; then /etc/init.d/dbus start 2>/dev/null || true; fi
if [ -x /etc/init.d/bluetooth ]; then /etc/init.d/bluetooth restart 2>/dev/null || /etc/init.d/bluetooth start 2>/dev/null || true; fi
echo
echo "[GenericBluetooth] Result:"
command -v bluetoothctl 2>/dev/null || true
for x in /usr/libexec/bluetooth/bluetoothd /usr/lib/bluetooth/bluetoothd /usr/sbin/bluetoothd /usr/bin/bluetoothd; do [ -x "$x" ] && echo "$x"; done
pidof bluetoothd 2>/dev/null || true
echo "[GenericBluetooth] Finished."
'''
        self.session.openWithCallback(self._installConsoleClosed, Console, "Install BlueZ", [cmd], closeOnSuccess=False)

    def _installConsoleClosed(self, *args):
        self.btctl = _which_fast(BTCTL_CANDIDATES, "bluetoothctl")
        self.bluetoothd = _which_fast(BTD_CANDIDATES, "bluetoothd")
        self.refresh()

    def scan(self):
        if self.busy:
            return
        if not self.btctl:
            self.installBlueZ()
            return
        if not self.controller:
            self.session.open(MessageBox, "No Bluetooth controller is available to BlueZ yet.", type=MessageBox.TYPE_ERROR, timeout=6)
            self.refresh()
            return
        addr = self.controller["address"]
        feed = "{ printf 'select %s\\npower on\\npairable on\\nscan on\\n'; sleep 12; printf 'scan off\\nquit\\n'; } | %s" % (addr, _q(self.btctl))
        cmd = self._timed_shell_prefix() + self._repair_shell() + "\n"
        cmd += "echo __GBT_SCAN_BEGIN__\n"
        cmd += "gb_run 18 /bin/sh -c %s 2>&1\n" % _q(feed)
        cmd += "echo __GBT_SCAN_END__\n"
        self.scan_discovered = []
        self._async(cmd, self._scanDone, "Scanning for Bluetooth devices (12 seconds)...")

    def _scanDone(self, rc, output):
        section = self._section(output, "__GBT_SCAN_BEGIN__", "__GBT_SCAN_END__")
        self.scan_discovered = self._parseDeviceLines(section)
        self.pending_refresh = False
        self._queryDevices()

    def _current_device(self):
        try:
            idx = self["list"].getSelectionIndex()
        except Exception:
            idx = None
        if idx is None or idx < 0 or idx >= len(self.devices):
            return None
        return self.devices[idx]

    def deviceActions(self):
        if self.busy:
            return
        d = self._current_device()
        if not d:
            self.session.open(MessageBox, "Select a Bluetooth device first. Use GREEN to scan.", type=MessageBox.TYPE_INFO, timeout=5)
            return
        self._queryDeviceInfo(d)

    def _queryDeviceInfo(self, device):
        lines = []
        if self.controller:
            lines.append("select %s" % self.controller["address"])
        lines += ["info %s" % device["address"], "quit"]
        script = "\n".join(lines) + "\n"
        inner = "printf %s | %s" % (_q(script), _q(self.btctl))
        cmd = self._timed_shell_prefix() + "\ngb_run 6 /bin/sh -c %s 2>&1\n" % _q(inner)
        self._async(cmd, lambda rc, out: self._deviceInfoDone(device, rc, out), "Reading %s..." % device["name"])

    def _deviceInfoDone(self, device, rc, output):
        state = {"paired": False, "trusted": False, "connected": False, "blocked": False}
        for raw in (output or "").splitlines():
            line = self._clean_bt_line(raw)
            for key in tuple(state.keys()):
                label = key.capitalize() + ":"
                if line.startswith(label):
                    state[key] = line.split(":", 1)[1].strip().lower() == "yes"
        choices = []
        if not state["connected"]:
            if not state["paired"]:
                choices.append(("Pair & Connect (Auto)", "pair_connect"))
            else:
                choices.append(("Connect", "connect"))
        else:
            choices.append(("Disconnect", "disconnect"))
        choices.append(("Untrust" if state["trusted"] else "Trust", "untrust" if state["trusted"] else "trust"))
        choices.append(("Unblock" if state["blocked"] else "Block", "unblock" if state["blocked"] else "block"))
        choices.append(("Remove / Forget", "remove"))
        choices.append(("Refresh", "refresh"))
        self.session.openWithCallback(lambda a: self._deviceActionChosen(a, device), ChoiceBox, title="%s\n%s" % (device["name"], device["address"]), list=choices)

    def _deviceActionChosen(self, answer, device):
        if not answer:
            return
        action = answer[1]
        if action == "refresh":
            self.refresh()
            return
        if action == "pair_connect":
            self._pairAndConnect(device)
            return
        if action == "connect":
            self._connectWithDiscovery(device)
            return

        lines = []
        if self.controller:
            lines.append("select %s" % self.controller["address"])
        lines.append("%s %s" % (action, device["address"]))
        lines.append("quit")
        script = "\n".join(lines) + "\n"
        inner = "printf %s | %s" % (_q(script), _q(self.btctl))
        cmd = self._timed_shell_prefix() + "\ngb_run 12 /bin/sh -c %s 2>&1\n" % _q(inner)
        self._async(cmd, lambda rc, out: self._deviceOpDone(action, device, rc, out), "%s %s..." % (action.capitalize(), device["name"]))

    def _pairAndConnect(self, device):
        if not self.btctl or not self.controller:
            self.refresh()
            return
        # Keep discovery active while pairing/connecting. This is important for
        # BLE devices because BlueZ Connect() needs a recent advertising report.
        # agent auto:NoInputNoOutput automatically accepts JustWorks pairing,
        # which is appropriate for remotes, mice, speakers and many gamepads.
        addr = device["address"]
        ctrl = self.controller["address"]
        feed = (
            "{ "
            "printf 'select %s\npower on\npairable on\nagent auto:NoInputNoOutput\ndefault-agent\nscan on\n'; "
            "sleep 4; "
            "printf 'pair %s\n'; "
            "sleep 18; "
            "printf 'trust %s\nconnect %s\n'; "
            "sleep 6; "
            "printf 'info %s\nscan off\nquit\n'; "
            "} | %s"
        ) % (ctrl, addr, addr, addr, addr, _q(self.btctl))
        cmd = self._timed_shell_prefix() + self._repair_shell() + "\n"
        cmd += "echo __GBT_PAIR_BEGIN__\n"
        cmd += "gb_run 38 /bin/sh -c %s 2>&1\n" % _q(feed)
        cmd += "echo __GBT_PAIR_END__\n"
        self._async(cmd, lambda rc, out: self._pairConnectDone(device, rc, out), "Pairing and connecting %s..." % device["name"])

    def _connectWithDiscovery(self, device):
        if not self.btctl or not self.controller:
            self.refresh()
            return
        addr = device["address"]
        ctrl = self.controller["address"]
        feed = (
            "{ "
            "printf 'select %s\npower on\nscan on\n'; "
            "sleep 4; "
            "printf 'connect %s\n'; "
            "sleep 7; "
            "printf 'info %s\nscan off\nquit\n'; "
            "} | %s"
        ) % (ctrl, addr, addr, _q(self.btctl))
        cmd = self._timed_shell_prefix() + "\n"
        cmd += "echo __GBT_CONNECT_BEGIN__\n"
        cmd += "gb_run 20 /bin/sh -c %s 2>&1\n" % _q(feed)
        cmd += "echo __GBT_CONNECT_END__\n"
        self._async(cmd, lambda rc, out: self._pairConnectDone(device, rc, out), "Connecting %s..." % device["name"])

    def _pairConnectDone(self, device, rc, output):
        text = output or ""
        lower = text.lower()
        paired = bool(re.search(r"(?:^|\n)\s*paired:\s*yes", text, re.I)) or "pairing successful" in lower
        trusted = bool(re.search(r"(?:^|\n)\s*trusted:\s*yes", text, re.I)) or "trust succeeded" in lower
        connected = bool(re.search(r"(?:^|\n)\s*connected:\s*yes", text, re.I)) or "connection successful" in lower

        # BlueZ may print an earlier transient error while a later retry succeeds;
        # final Connected/Paired state wins over textual error words.
        failed = not connected and (rc != 0 or "failed" in lower or "error" in lower or "not available" in lower)
        if connected:
            msg = "%s is connected." % device["name"]
            if paired or trusted:
                msg += "\nPaired: %s   Trusted: %s" % ("yes" if paired else "unknown", "yes" if trusted else "unknown")
            self.session.open(MessageBox, msg, type=MessageBox.TYPE_INFO, timeout=6)
        elif paired:
            self.session.open(MessageBox, "%s paired successfully but is not connected yet.\n\nPut the device back in pairing/advertising mode and choose Connect.\n\n%s" % (device["name"], text[-1200:]), type=MessageBox.TYPE_INFO)
        else:
            title = "Pair/connect failed" if failed else "Device did not report Connected: yes"
            self.session.open(MessageBox, "%s for %s.\n\n%s" % (title, device["name"], text[-1600:] or "No diagnostic output"), type=MessageBox.TYPE_ERROR)
        self.refresh()

    def _deviceOpDone(self, action, device, rc, output):
        lower = (output or "").lower()
        failed = rc != 0 or "failed" in lower or "error" in lower
        if failed:
            self.session.open(MessageBox, "%s failed for %s.\n\n%s" % (action.capitalize(), device["name"], (output or "No diagnostic output")[-1200:]), type=MessageBox.TYPE_ERROR)
        else:
            self.session.open(MessageBox, "%s completed for %s." % (action.capitalize(), device["name"]), type=MessageBox.TYPE_INFO, timeout=5)
        self.refresh()

    # ------------------------------------------------------------------
    # Single async process runner used for ALL external commands.
    # ------------------------------------------------------------------

    def _async(self, cmd, done, status):
        if self.busy:
            self.pending_refresh = self.pending_refresh or (done == self._probeDone)
            return
        self.busy = True
        self["status"].setText(status)
        self.console_output = []
        self.pending_done = done
        self.console = eConsoleAppContainer()
        try:
            self.console.dataAvail.append(self._consoleData)
            self.console.appClosed.append(self._consoleClosed)
        except Exception:
            self.console_data_conn = self.console.dataAvail.connect(self._consoleData)
            self.console_close_conn = self.console.appClosed.connect(self._consoleClosed)
        rc = self.console.execute("/bin/sh", "sh", "-c", cmd)
        if rc:
            self.busy = False
            self.console = None
            self["status"].setText("Could not start Bluetooth background command.")

    def _consoleData(self, data):
        try:
            if isinstance(data, bytes):
                data = data.decode("utf-8", "replace")
            self.console_output.append(str(data))
        except Exception:
            pass

    def _consoleClosed(self, rc):
        output = "".join(self.console_output)
        done = self.pending_done
        self.pending_done = None
        self.console = None
        self.busy = False
        try:
            if done:
                done(rc, output)
        except Exception as e:
            self.session.open(MessageBox, "Bluetooth operation error: %s" % e, type=MessageBox.TYPE_ERROR)
            self._renderStatus()
        if self.pending_refresh and not self.busy:
            self.pending_refresh = False
            self.refresh()


def main(session, **kwargs):
    session.open(BluetoothSetup)


def menu(menuid, **kwargs):
    if menuid == "system":
        return [("Bluetooth Setup", main, "generic_bluetooth_setup", 55)]
    return []


def Plugins(**kwargs):
    return [
        PluginDescriptor(name="Bluetooth Setup", description="Generic BlueZ Bluetooth setup", where=PluginDescriptor.WHERE_MENU, fnc=menu),
        PluginDescriptor(name="Bluetooth Setup", description="Generic BlueZ Bluetooth setup", where=PluginDescriptor.WHERE_PLUGINMENU, fnc=main),
    ]
