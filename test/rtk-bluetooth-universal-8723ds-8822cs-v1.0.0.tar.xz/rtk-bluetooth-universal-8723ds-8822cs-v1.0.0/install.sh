#!/bin/sh
set -e
BASE="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
TS="$(date +%Y%m%d-%H%M%S 2>/dev/null || echo backup)"

mkdir -p /etc/init.d /etc/default /usr/bin
[ -e /etc/init.d/rtk-bluetooth ] && cp -a /etc/init.d/rtk-bluetooth "/etc/init.d/rtk-bluetooth.backup-$TS"
[ -e /etc/default/rtk-bluetooth ] && cp -a /etc/default/rtk-bluetooth "/etc/default/rtk-bluetooth.backup-$TS"

cp -f "$BASE/payload/etc/init.d/rtk-bluetooth" /etc/init.d/rtk-bluetooth
cp -f "$BASE/payload/etc/default/rtk-bluetooth" /etc/default/rtk-bluetooth
cp -f "$BASE/payload/usr/bin/rtk-bluetooth-firmware-aliases" /usr/bin/rtk-bluetooth-firmware-aliases
chmod 755 /etc/init.d/rtk-bluetooth /usr/bin/rtk-bluetooth-firmware-aliases
chmod 644 /etc/default/rtk-bluetooth
/usr/bin/rtk-bluetooth-firmware-aliases || true

echo "Installed universal Realtek UART Bluetooth init service."
echo "Uses existing /usr/bin/rtk_hciattach; no binary was replaced."
echo "Supports RTL8723DS and RTL8822CS if firmware/config files are present."
echo "Start/test with: /etc/init.d/rtk-bluetooth restart"
