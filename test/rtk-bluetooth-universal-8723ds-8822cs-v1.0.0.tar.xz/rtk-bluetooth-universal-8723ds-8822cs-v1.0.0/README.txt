Universal Realtek UART Bluetooth init service
=============================================

This package does NOT replace rtk_hciattach.
It uses the existing binary that already works with RTL8723DS and RTL8822CS.

Default command:
  rtk_hciattach -n -s 115200 <uart> rtk_h5 1500000

Chip selection is done by rtk_hciattach itself after reading the controller.
Expected firmware names under /lib/firmware/rtlbt/:
  RTL8723DS: rtl8723d_fw / rtl8723d_config
  RTL8822CS: rtl8822cs_fw / rtl8822cs_config

The helper creates non-.bin aliases from standard rtl_bt/*.bin files when available,
without overwriting existing firmware.

Configuration:
  /etc/default/rtk-bluetooth

Default UART mode is auto, preferring ttyS1, ttyS2, ttyS3, ttyAML1, ttyAML2
and skipping any UART used as the kernel console.

Commands:
  /etc/init.d/rtk-bluetooth start
  /etc/init.d/rtk-bluetooth stop
  /etc/init.d/rtk-bluetooth restart
  /etc/init.d/rtk-bluetooth status

Logs:
  /tmp/rtk_hciattach.log
  /tmp/rtk-bluetooth-state
