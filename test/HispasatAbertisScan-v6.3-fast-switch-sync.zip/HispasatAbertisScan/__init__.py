# Hispasat Abertis Scan helper
