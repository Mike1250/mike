# -*- coding: utf-8 -*-
# Hispasat/Abertis userspace carrier configuration for plugin v6.0.
# ALL RF/carrier-specific values live here.  The kernel driver contains none.
# GPL-2.0-or-later

# Enigma2 orbital position: 30.0W = 3300 in the 0..3599 representation.
ORBITAL_POSITION = 3300

# CA_PMT defaults.  These are userspace policy and may be overridden here.
CAID = 0x2600
FAKE_ECM_PID = 0x1FFF
ADAPTER = 0
DEMUX = 1
CA_DEVICE = 1
CHILD_MUX_PRIME_DELAY = 0.12

# Profile tuple:
#   (name, RF frequency kHz, symbol rate, polarisation,
#       [(outer source SID, hidden carrier PID, outer PMT PID), ...])
#
# outer_pmt_pid is EXPLICIT on purpose.  The plugin does not derive it from
# hidden_pid, so a broadcaster change is edited in this file only.
PROFILES = [
    ("11222H", 11222000, 30000000, "H", [
        (3025, 2025, 7025), (3026, 2026, 7026), (3027, 2027, 7027),
        (3028, 2028, 7028), (3050, 2050, 7050), (3060, 2060, 7060),
    ]),
    ("11302H", 11302000, 30000000, "H", [
        (3270, 2270, 7270), (3271, 2271, 7271), (3272, 2272, 7272),
        (3273, 2273, 7273), (3274, 2274, 7274),
    ]),
    ("11347H", 11347000, 20858000, "H", [
        (3302, 2302, 7302), (3303, 2303, 7303), (3305, 2305, 7305),
        (3306, 2306, 7306), (3308, 2308, 7308),
    ]),
    ("11382H", 11382000, 30000000, "H", [
        (3520, 2520, 7520), (3521, 2521, 7521), (3522, 2522, 7522),
        (3523, 2523, 7523), (3524, 2524, 7524),
    ]),
    ("11502V", 11502000, 10200000, "V", [
        (1801, 801, 5801),
    ]),
    ("11653H", 11653000, 19680000, "H", [
        (1301, 301, 5301), (1303, 303, 5303),
    ]),
    ("11675H", 11675000, 15750000, "H", [
        (1420, 420, 5420), (1421, 421, 5421), (1423, 423, 5423),
    ]),
    ("12548V", 12548000, 29600000, "V", [
        (1701, 701, 5701), (1702, 702, 5702), (1703, 703, 5703),
    ]),
    ("12583V", 12583000, 16900000, "V", [
        (1008, 8008, 5008),
    ]),
    ("12631V", 12631000, 30000000, "V", [
        (1001, 8001, 5001), (1002, 8002, 5002), (1003, 8003, 5003),
    ]),
    ("12671V", 12671000, 30000000, "V", [
        (1000, 8000, 5000), (1004, 8004, 5004), (1005, 8005, 5005),
        (1006, 8006, 5006),
    ]),
]


def carrier_values(carrier):
    """Return (source_sid, hidden_pid, outer_pmt_pid); no derivation."""
    if len(carrier) < 3:
        raise ValueError("carrier entry needs source_sid, hidden_pid, outer_pmt_pid")
    return int(carrier[0]), int(carrier[1]), int(carrier[2])


def find_profile(name):
    for profile in PROFILES:
        if profile[0] == name:
            return profile
    return None


def find_carrier(profile, source_sid, hidden_pid):
    """Return explicit (source_sid, hidden_pid, outer_pmt_pid) from config."""
    if profile is None:
        return None
    for carrier in profile[4]:
        sid, pid, pmt = carrier_values(carrier)
        if sid == int(source_sid) and pid == int(hidden_pid):
            return sid, pid, pmt
    return None
